"""
Personal Finance Expense Analyzer
Bennett University | 2026CSAE100
Student: Parv Singhal | Enrollment: S26CSEU1315

Run: python personal_finance_expense_analyzer.py
No external packages are required.
"""

def get_positive_amount(prompt):
    """Read a positive expense amount; reject invalid and negative values."""
    while True:
        raw = input(prompt).strip()
        try:
            amount = float(raw)
            if amount <= 0:
                print("Amount must be greater than zero. Try again.")
                continue
            return amount
        except ValueError:
            print("Invalid input. Please enter a number (example: 250 or 99.50).")


def get_budget():
    while True:
        budget = get_positive_amount("Enter your monthly budget (₹): ")
        return budget


def add_expense(expenses):
    category = input("Enter category (Food/Travel/Study/Bills/Shopping/Other): ").strip()
    while not category:
        print("Category cannot be empty.")
        category = input("Enter category: ").strip()

    amount = get_positive_amount("Enter amount (₹): ")
    note = input("Enter a short note: ").strip() or "No note"

    expense = {"category": category.title(), "amount": amount, "note": note}
    expenses.append(expense)
    print("Expense added successfully.")


def view_expenses(expenses):
    if not expenses:
        print("\nNo expenses recorded yet.")
        return

    print("\n{:<5} {:<16} {:>12}   {}".format("No.", "Category", "Amount (₹)", "Note"))
    print("-" * 65)
    for number, expense in enumerate(expenses, start=1):
        print("{:<5} {:<16} {:>12.2f}   {}".format(
            number, expense["category"], expense["amount"], expense["note"]
        ))


def analyze_expenses(expenses, budget):
    if not expenses:
        print("\nAdd at least one expense before analysis.")
        return

    total = sum(item["amount"] for item in expenses)
    category_totals = {}
    for item in expenses:
        category = item["category"]
        category_totals[category] = category_totals.get(category, 0) + item["amount"]

    print("\n========== EXPENSE ANALYSIS ==========")
    print(f"Monthly budget : ₹{budget:.2f}")
    print(f"Total spending : ₹{total:.2f}")
    print(f"Remaining      : ₹{budget - total:.2f}")
    print("\nCategory-wise spending:")
    for category, amount in sorted(category_totals.items(),
                                   key=lambda pair: pair[1], reverse=True):
        percentage = (amount / total) * 100
        print(f"- {category:<15} ₹{amount:>10.2f} ({percentage:.1f}%)")

    highest_category = max(category_totals, key=category_totals.get)
    print(f"\nHighest spending category: {highest_category}")

    usage = (total / budget) * 100
    print(f"Budget used: {usage:.1f}%")
    if total > budget:
        print("Status: OVER BUDGET")
    elif total == budget:
        print("Status: BUDGET FULLY USED")
    elif usage >= 80:
        print("Status: WARNING - 80% or more of the budget has been used.")
    else:
        print("Status: WITHIN BUDGET")


def show_sorted_expenses(expenses):
    if not expenses:
        print("\nNo expenses to sort.")
        return
    # Python's sorted() returns a new list; the original entry order is preserved.
    ordered = sorted(expenses, key=lambda item: item["amount"], reverse=True)
    print("\nExpenses sorted from highest to lowest amount:")
    for number, item in enumerate(ordered, start=1):
        print(f"{number}. {item['category']}: ₹{item['amount']:.2f} — {item['note']}")


def main():
    print("PERSONAL FINANCE EXPENSE ANALYZER")
    budget = get_budget()
    expenses = []

    while True:
        print("\n--------------- MENU ---------------")
        print("1. Add expense")
        print("2. View all expenses")
        print("3. Analyze expenses and budget")
        print("4. Sort expenses (highest to lowest)")
        print("5. Exit")
        choice = input("Choose an option (1-5): ").strip()

        if choice == "1":
            add_expense(expenses)
        elif choice == "2":
            view_expenses(expenses)
        elif choice == "3":
            analyze_expenses(expenses, budget)
        elif choice == "4":
            show_sorted_expenses(expenses)
        elif choice == "5":
            print("Thank you for using Personal Finance Expense Analyzer!")
            break
        else:
            print("Invalid menu choice. Please select 1, 2, 3, 4 or 5.")


if __name__ == "__main__":
    main()
